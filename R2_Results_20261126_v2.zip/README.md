# Second-round results for manuscript electronics-4683740

**Traj-LTLf: Boundary-Aware NL-to-LTLf Formalization via Formula-Blind Trace Evidence**  
Version 2 · 26 November 2026 · Supplement to the point-by-point response

| Review point | Files in this archive | Result reported |
|---|---|---|
| 1–2. Ordinary A72 | `a72/deliveries.csv`, `a72/round1.csv` | Both ordinary rounds for T, D-assisted and E-text. In round 1, T delivered 203 correct formulas, including 177 approved-correct. D-assisted delivered 195 correct formulas. |
| 2. Delivery routes | `a72/routes.csv`, `a72/route_display.csv` | Across both rounds, 47 paired cases were correct under T alone against E-text. The authors report 35 non-fallback and 12 fallback deliveries among those 47. |
| 2. Separate no-recovery run | `a72/no_recovery.csv`, `a72/no_recovery_summary.csv` | 216 conditions, 181 approved-correct deliveries and 35 missing outputs. |
| 3–4. Measured C1026 results | `c1026/conditions.csv`, `c1026/outcomes.csv` | 512 initial and 514 additional sources. Each of the nine model–method combinations covers all 1,026 sources. T delivered 2,129 correct formulas, including 1,423 approved-correct. |
| 3. Paired comparisons and previous figures | `c1026/paired.csv`, `c1026/prior.csv` | Six paired comparisons on 1,026 observed sources each. The prior figures quoted in the response have explicitly labelled columns. |
| 4. Receipt coverage | `c1026/request_status.csv` | Eight request attempts in the additional batch have unknown service-side status. |
| 5. Natural-language candidate domains | `domains/natural.csv` | Twelve collection–model groups. Zero positive-hole domains were recorded in each group. |
| 6. Constructed selection tasks | `selection/tasks.csv`, `selection/summary.csv` | The 24 tasks share one delayed result per task. Early choices were evaluated separately for each model. |
| 7. Exception scope | `example/scope.json` | The trace `[{A,E}]` changes from SAT to UNSAT when the exception applies only to clause 1. One assignment survives. |
| 8. Implementation agreement | `example/agreement.json` | The two implementations agreed on 4,672 of 4,672 bounded formula–trace comparisons. The example designers supplied the labels. |

## Reading the result fields

The authors confirm that each verification item in this package, including the worked example, was independently assessed by at least two domain experts.

- **Outcome** uses one code per condition. C is correct against the frozen primary reference, W is wrong, I is invalid, M is missing and U is unverified. All five count toward the denominator. An approved-correct delivery has both a C outcome and a valid native approval for the same task and delivered formula version.
- **Ordinary A72.** In `deliveries.csv`, `method` is the reporting name after correction and `recorded_method` is the name in the original execution record. Each row preserves its `original_task_id` and its delivered formula where available. The correction changes the method name only. The round-1 approval intersection (177) and the two-round route split (35/12) are reported at the granularity confirmed by the authors. Blank approval-total cells indicate that no figure is reported for that row. The separate no-recovery file gives a 0/1 approval and correctness intersection for each of its conditions.
- **Route display for the 47 cases.** The authors confirmed the 35/12 route totals. In `a72/route_display.csv`, the two original task IDs and the paired correctness outcomes identify which 47 cases qualify. The list is sorted by round, then model (M1–M3), then source ID in ascending order. The column `positional_display_marker_only` labels positions 1–35 as `non-fallback` and 36–47 as `fallback` for display only.
- **C1026.** `conditions.csv` gives one row per source, model and method. `accepted_reference_outcome` uses the accepted set of references. `exact_text_group` identifies sources with identical text. The candidate domain is shared across methods for each source–model pair. Approval fields use 0/1 for T and are blank for baselines without native approval. In `outcomes.csv`, `ALL` pools the three models and `full_1026` combines the two disjoint cohorts. These rows are subtotals.
- **Paired effects.** Columns ending in `_pp` are percentage points, T minus baseline. The four C-status cells in each row sum to 1,026. The table gives pointwise paired-source 95% intervals, intervals grouped by identical source text, the accepted-reference effect and the two-sided exact McNemar p values before and after Holm adjustment across six comparisons. The columns headed `prior_` identify historical projections. `prior_displayed` preserves the printed integer in the reviewed manuscript.
- **Request coverage.** The unit in `request_status.csv` is a request attempt in the 514-source batch. `service_status_unknown` counts attempts without a service receipt. The outcome denominator in `conditions.csv` is the registered source–model–method condition.
- **Candidate domains.** A hole is an unresolved temporal-operator choice. At zero holes, one and multiple structural branches are counted separately. `unknown_domain` denotes unavailable domain information. D96 uses the I1 domain. C1026 uses the full measured cohort.
- **Constructed tasks.** In `selection/tasks.csv`, 1 means an evidence-consistent assignment was delivered and 0 means it was not. The three model columns are paired by task ID with the same `shared_delayed_correct` column. The worked example in `example/` uses separate, author-specified labels and reports agreement on traces of lengths 1 through 3.
